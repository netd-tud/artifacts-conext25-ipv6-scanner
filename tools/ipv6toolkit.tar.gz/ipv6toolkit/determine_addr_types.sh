#!/bin/bash

# Set the program variable
program="$2"

export program 

# Define the function to determine address type
determine_addr_type() {
    addr="$1"
    addrtype=$("$program" -a "$addr" | awk -F'=' '{print $4}')
    echo "$addr|$addrtype"
}

# Export the function for use with parallel
export -f determine_addr_type

# Open input and output files
input_file="$1"
output_file="$3"

# Process the input file in parallel
parallel -a "$1" --progress -j 252 determine_addr_type > "$3"
#while IFS= read -r line; do
#    addr="$line"
#    addrtype=$("$program" -a "$addr" | awk -F'=' '{print $4}')
#    echo "$addr|$addrtype"
#done < "$input_file" > "$output_file"

echo "Processing completed successfully."

