/*
 * Header file for the flow6 tool
 *
 */

#define	QUERY_TIMEOUT			65



