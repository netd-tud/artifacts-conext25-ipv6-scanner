#define SI6_TOOLKIT "SI6 Networks' IPv6 Toolkit (current)"
#define	MAX_CMDLINE_OPT_LEN	40
#define DATE_STR_LEN		40

