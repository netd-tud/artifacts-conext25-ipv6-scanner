/*
 * Header file for the jumbo6 tool
 *
 */

#define	QUERY_TIMEOUT			2

